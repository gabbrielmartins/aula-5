# Modelos Autorregressivos
Material didático para aula 5 de Econometria de Séries Temporais na USJT
